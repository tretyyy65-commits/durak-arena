package com.nexora.durakarena;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends Activity {
    private static final int RC_SIGN_IN = 9001;
    private FirebaseAuth auth;
    private GoogleSignInClient googleClient;
    private TextView status;
    private Button googleButton;
    private Button logoutButton;
    private TextView playerId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth = FirebaseAuth.getInstance();

        GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(com.google.android.gms.auth.api.R.string.common_google_play_services_unknown_issue))
                .requestEmail()
                .build();

        // The Google web client ID is supplied by google-services.json at build time.
        String webClientId = getString(getResources().getIdentifier("default_web_client_id", "string", getPackageName()));
        if (webClientId != null && !webClientId.isEmpty()) {
            options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestIdToken(webClientId)
                    .requestEmail()
                    .build();
        }
        googleClient = GoogleSignIn.getClient(this, options);

        buildUi();
        updateUser(auth.getCurrentUser());
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(28), dp(34), dp(28), dp(28));
        root.setBackgroundColor(Color.rgb(8, 8, 8));

        TextView nexora = text("NEXORA\nINTERACTIVE", 21, Color.rgb(216,168,76), true);
        nexora.setGravity(Gravity.CENTER);
        root.addView(nexora, new LinearLayout.LayoutParams(-1, dp(90)));

        TextView title = text("DURAK ARENA", 32, Color.rgb(216,168,76), true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(95)));

        TextView welcome = text("ЛАСКАВО ПРОСИМО", 18, Color.WHITE, true);
        welcome.setGravity(Gravity.CENTER);
        root.addView(welcome, new LinearLayout.LayoutParams(-1, dp(55)));

        googleButton = new Button(this);
        googleButton.setText("Продовжити через Google");
        googleButton.setTextSize(16);
        googleButton.setAllCaps(false);
        googleButton.setOnClickListener(v -> signIn());
        root.addView(googleButton, new LinearLayout.LayoutParams(-1, dp(58)));

        status = text("Без входу", 15, Color.LTGRAY, false);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(70));
        sp.topMargin = dp(16);
        root.addView(status, sp);

        playerId = text("", 17, Color.rgb(216,168,76), true);
        playerId.setGravity(Gravity.CENTER);
        root.addView(playerId, new LinearLayout.LayoutParams(-1, dp(45)));

        logoutButton = new Button(this);
        logoutButton.setText("Вийти з акаунта");
        logoutButton.setAllCaps(false);
        logoutButton.setVisibility(View.GONE);
        logoutButton.setOnClickListener(v -> signOut());
        root.addView(logoutButton, new LinearLayout.LayoutParams(-1, dp(54)));

        TextView info = text("Безпечний вхід через Google. Акаунт зберігається Firebase.", 13, Color.GRAY, false);
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, dp(70));
        ip.topMargin = dp(18);
        root.addView(info, ip);

        setContentView(root);
    }

    private void signIn() {
        status.setText("Відкриваємо Google…");
        googleButton.setEnabled(false);
        startActivityForResult(googleClient.getSignInIntent(), RC_SIGN_IN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != RC_SIGN_IN) return;

        Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
        try {
            GoogleSignInAccount account = task.getResult(ApiException.class);
            AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
            auth.signInWithCredential(credential).addOnCompleteListener(this, result -> {
                googleButton.setEnabled(true);
                if (result.isSuccessful()) {
                    updateUser(auth.getCurrentUser());
                } else {
                    status.setText("Не вдалося виконати вхід");
                    Toast.makeText(this, "Помилка Firebase: " + (result.getException() == null ? "невідома" : result.getException().getMessage()), Toast.LENGTH_LONG).show();
                }
            });
        } catch (Exception e) {
            googleButton.setEnabled(true);
            status.setText("Вхід скасовано або не виконано");
        }
    }

    private void signOut() {
        auth.signOut();
        googleClient.signOut();
        updateUser(null);
    }

    private void updateUser(FirebaseUser user) {
        if (user == null) {
            status.setText("Увійдіть через Google, щоб продовжити");
            playerId.setText("");
            googleButton.setVisibility(View.VISIBLE);
            logoutButton.setVisibility(View.GONE);
            return;
        }
        String name = user.getDisplayName() == null ? "Гравець" : user.getDisplayName();
        String id = makePlayerId(user.getUid());
        status.setText("Вітаємо, " + name);
        playerId.setText("ID гравця: " + id);
        googleButton.setVisibility(View.GONE);
        logoutButton.setVisibility(View.VISIBLE);
    }

    private String makePlayerId(String uid) {
        String clean = uid.replaceAll("[^A-Za-z0-9]", "").toUpperCase();
        if (clean.length() > 8) clean = clean.substring(0, 8);
        while (clean.length() < 8) clean += "X";
        return "#" + clean;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
