# Durak Arena Android Starter
Package: com.nexora.durakarena
Firebase google-services.json is included.
Next: real Google Sign-In, then the main menu.
