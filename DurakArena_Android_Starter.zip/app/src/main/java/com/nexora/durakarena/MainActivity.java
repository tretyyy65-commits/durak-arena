package com.nexora.durakarena;
import android.app.Activity; import android.os.Bundle; import android.graphics.Color; import android.view.Gravity; import android.widget.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setGravity(Gravity.CENTER); r.setPadding(32,40,32,40); r.setBackgroundColor(Color.rgb(8,8,8));
 TextView n=new TextView(this); n.setText("NEXORA\nINTERACTIVE"); n.setTextColor(Color.rgb(216,168,76)); n.setTextSize(22); n.setGravity(17); r.addView(n,new LinearLayout.LayoutParams(-1,120));
 TextView t=new TextView(this); t.setText("DURAK ARENA"); t.setTextColor(Color.rgb(216,168,76)); t.setTextSize(34); t.setGravity(17); r.addView(t,new LinearLayout.LayoutParams(-1,120));
 TextView w=new TextView(this); w.setText("ЛАСКАВО ПРОСИМО"); w.setTextColor(Color.WHITE); w.setTextSize(18); w.setGravity(17); r.addView(w,new LinearLayout.LayoutParams(-1,80));
 Button g=new Button(this); g.setText("Продовжити через Google"); r.addView(g,new LinearLayout.LayoutParams(-1,80));
 TextView s=new TextView(this); s.setText("Firebase підключений. Наступним кроком додамо реальний Google Sign-In."); s.setTextColor(Color.LTGRAY); s.setGravity(17); s.setPadding(10,30,10,0); r.addView(s,new LinearLayout.LayoutParams(-1,140)); setContentView(r);}
}
