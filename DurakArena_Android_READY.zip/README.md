# DURAK ARENA — Android Ready

Готовий Android-проєкт `com.nexora.durakarena` з Firebase Authentication та Google Sign-In.

## Що вже є
- реальний вхід через Google/Gmail;
- Firebase Authentication;
- автоматичне збереження авторизації на пристрої;
- вихід з акаунта;
- автоматичний ID гравця формату `#XXXXXXXX`;
- готова структура Gradle Android.

## Перед першим APK
У Firebase Console для Android-застосунку `com.nexora.durakarena` потрібно додати SHA-1 сертифіката збірки та переконатися, що Google Sign-In увімкнений у Authentication.

Цей ZIP уже містить `google-services.json` для проєкту Firebase `arena-durak`.
